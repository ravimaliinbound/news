var validationMsg = {
	"name_required" : 'الرجاء إدخال الدور',
	"role_exists" : 'هذا الدور موجود بالفعل',
	"module_required" : 'الرجاء تحديد وحدة واحدة على الأقل من القائمة',
}
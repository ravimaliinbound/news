var validationMsg = {
	"name_required" : 'Please enter role',
	"role_exists" : 'This role already exists',
	"module_required" : 'Please select atlease one module from list',
}
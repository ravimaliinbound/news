<?php

use Illuminate\Support\Facades\Route;

// Authentication admin Login Routes
Route::get('login', 'Auth\LoginController@showLoginForm')->name('admin.login');
Route::post('login', 'Auth\LoginController@login')->name('admin.postlogin');
Route::get('logout/{id?}', 'Auth\LoginController@logout')->name('admin.logout');

//forget and reset password
Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('admin.auth.password.reset');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('admin.passwordemail');
Route::get('password/reset/{token?}', 'Auth\ResetPasswordController@showResetForm')->name('admin.auth.password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('admin.resetpassword');

//Dashboard Route....
Route::get('/', 'AdminController@index')->name('admin.dashboard');
Route::get('/manage-profile', 'AdminController@editProfile')->name('admin.profile');
Route::post('/edit-profile', 'AdminController@updateProfile')->name('admin.updateProfile');

Route::group(['prefix' => 'user'], function () {
    Route::get('/create', 'VendorController@create')->name('admin.vendor.create');
    Route::post('/createPost', 'VendorController@createPost')->name('admin.vendor.createPost');

    Route::get('/list', 'VendorController@list')->name('admin.vendor.list');
    Route::get('/edit/{id}', 'VendorController@editVendor')->name('admin.vendor.edit');
    Route::post('/update', 'VendorController@updateVenderInventory')->name('admin.vendor.inventory.update');
    Route::get('/filter', 'VendorController@inventoryVendor')->name('admin.vendor.filter');
    Route::get('/delete/{id}', 'VendorController@destroy')->name('admin.vendor.delete');
    Route::post('/save-edited-vendor', 'VendorController@saveEditedVendor')->name('admin.saveEditedVendor');
    Route::post('/check-vendor-email', 'VendorController@checkVendorEmail')->name('admin.checkVendorEmail');
    Route::post('/chagne-vendor-status', 'VendorController@chagneVendorStatus')->name('admin.chagneVendorStatus');
});
Route::group(['prefix' => 'category'], function () {
    Route::match(['get', 'post'], '/list', 'CategoryController@index')->name('admin.category.list');
    Route::get('/create', 'CategoryController@create')->name('admin.category.create');
    Route::post('/store', 'CategoryController@store')->name('admin.category.store');
    Route::get('/edit/{id}', 'CategoryController@edit')->name('admin.category.edit');
    Route::post('/update', 'CategoryController@update')->name('admin.category.update');
    Route::get('/delete/{id}', 'CategoryController@destroy')->name('admin.category.delete');
    // Route::post('/check-service-name', 'CategoryController@checkServiceName')->name('admin.checkServiceName');
});

Route::group(['prefix' => 'packaging'], function () {
    Route::match(['get', 'post'], '/list', 'PackagingSlipController@index')->name('admin.packaging.list');
    Route::get('/create', 'PackagingSlipController@create')->name('admin.packaging.create');
    Route::post('/store', 'PackagingSlipController@store')->name('admin.packaging.store');
    Route::get('/edit/{id}', 'PackagingSlipController@edit')->name('admin.packaging.edit');
    Route::get('/view/{id}', 'PackagingSlipController@view')->name('admin.packaging.view');
    Route::post('/edit/{id}', 'PackagingSlipController@update')->name('admin.packaging.update');
    Route::get('/delete/{id}', 'PackagingSlipController@destroy')->name('admin.packaging.delete');
    Route::get('/download/{id}', 'PackagingSlipController@generatePdf')->name('admin.packaging.generatePdf');
    Route::get('/download/assorting/{id}', 'PackagingSlipController@assorting')->name('admin.packaging.assorting');
    // Route::post('/check-service-name', 'PackagingSlipController@checkServiceName')->name('admin.checkServiceName');
});

Route::match(['get', 'post'], '/quality/list', 'QualityController@index')->name('admin.quality.list');
Route::get('/quality/create', 'QualityController@create')->name('admin.quality.add');
Route::post('/quality/store', 'QualityController@store')->name('admin.quality.store');
Route::get('/quality/edit/{id}', 'QualityController@edit')->name('admin.quality.edit');
Route::post('/quality/edit/{id}', 'QualityController@update')->name('admin.quality.update');
Route::get('/quality/delete/{id}', 'QualityController@destroy')->name('admin.quality.delete');

Route::match(['get', 'post'], '/gatepass/list', 'GatePassController@index')->name('admin.gatepass.list');
Route::get('/gatepass/create', 'GatePassController@create')->name('admin.gatepass.add');
Route::get('/gatepass/edit/{id}', 'GatePassController@edit')->name('admin.gatepass.edit');
Route::get('/gatepass/view/{id}', 'GatePassController@view')->name('admin.gatepass.view');
Route::post('/gatepass/edit/{id}', 'GatePassController@update')->name('admin.gatepass.update');
Route::post('/gatepass/store', 'GatePassController@store')->name('admin.gatepass.store');
Route::get('/gatepass/download/{id}', 'GatePassController@generateGatePass')->name('admin.gatepass.generateGatePass');
Route::get('/gatepass/delete/{id}', 'GatePassController@destroy')->name('admin.gatepass.delete');


Route::match(['get', 'post'], '/inward/list', 'InwardController@index')->name('admin.inward.list');
Route::get('/inward/create', 'InwardController@create')->name('admin.inward.add');
Route::get('/inward/edit/{id}', 'InwardController@edit')->name('admin.inward.edit');
Route::get('/inward/view/{id}', 'InwardController@view')->name('admin.inward.view');
Route::post('/inward/edit/{id}', 'InwardController@update')->name('admin.inward.update');
Route::post('/inward/store', 'InwardController@store')->name('admin.inward.store');
Route::get('/inward/download/{id}', 'InwardController@generateinward')->name('admin.inward.inwardPass');
Route::get('/inward/delete/{id}', 'InwardController@destroy')->name('admin.inward.delete');

Route::match(['get', 'post'], '/sample/list', 'SampleController@index')->name('admin.sample.list');
Route::get('/sample/create', 'SampleController@create')->name('admin.sample.add');
Route::get('/sample/edit/{id}', 'SampleController@edit')->name('admin.sample.edit');
Route::get('/sample/view/{id}', 'SampleController@view')->name('admin.sample.view');
Route::post('/sample/edit/{id}', 'SampleController@update')->name('admin.sample.update');
Route::post('/sample/store', 'SampleController@store')->name('admin.sample.store');
Route::get('/sample/download/{id}', 'SampleController@generatesample')->name('admin.sample.samplePass');
Route::get('/sample/delete/{id}', 'SampleController@destroy')->name('admin.sample.delete');

Route::match(['get', 'post'], '/defective/list', 'DefectiveController@index')->name('admin.defective.list');
Route::get('/defective/create', 'DefectiveController@create')->name('admin.defective.add');
Route::get('/defective/edit/{id}', 'DefectiveController@edit')->name('admin.defective.edit');
Route::get('/defective/view/{id}', 'DefectiveController@view')->name('admin.defective.view');
Route::post('/defective/edit/{id}', 'DefectiveController@update')->name('admin.defective.update');
Route::post('/defective/store', 'DefectiveController@store')->name('admin.defective.store');
Route::get('/defective/download/{id}', 'DefectiveController@generatedefective')->name('admin.defective.defectivePass');
Route::get('/defective/delete/{id}', 'DefectiveController@destroy')->name('admin.defective.delete');

Route::match(['get', 'post'], '/warehouse/list', 'WareHouseController@index')->name('admin.warehouse.list');
Route::get('/warehouse/create', 'WareHouseController@create')->name('admin.warehouse.add');
Route::post('/warehouse/store', 'WareHouseController@store')->name('admin.warehouse.store');
Route::get('/warehouse/edit/{id}', 'WareHouseController@edit')->name('admin.warehouse.edit');
Route::post('/warehouse/edit/{id}', 'WareHouseController@update')->name('admin.warehouse.update');
Route::get('/warehouse/delete/{id}', 'WareHouseController@destroy')->name('admin.warehouse.delete');




// Route::get('/hash-password', function () {
//         return Hash::make('palrechaAdmin!@#2025');
//     });


// Route::get('/hash-password', function () {
//     return Hash::make('plexpoAdmin!@#2024');
// });
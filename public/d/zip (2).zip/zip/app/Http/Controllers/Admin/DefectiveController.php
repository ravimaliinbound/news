<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Defective;
use App\Models\PackagingSlip;
use PDF;

class DefectiveController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index()
    {
        $defective = Defective::get();
        return view('admin.defective.list', compact('defective'));
    }
    public function create(Request $request)
    {
        $nextId = Defective::max('id') + 1;

        $packaging = PackagingSlip::with(['items', 'color', 'assorting', 'inwarded'])
            ->where('is_delete', 0)
            ->orderBy('id', 'desc')
            ->get();

        return view('admin.defective.add', compact('packaging', 'nextId'));
    }
    public function store(Request $request)
    {
        Defective::create([
            'packaging_id' => $request->packaging_id,
            'item_id' => $request->item_id,
            'quantity' => $request->quantity,
        ]);

        return redirect()->route('admin.defective.list')->with('messages', [
            ['type' => 'success', 'message' => 'Defective stored successfully', 'title' => 'Success!']
        ]);
    }

    public function edit(Request $request, $id)
    {
        $defective = Defective::find($id);
        $packaging = PackagingSlip::where('id', $defective->packaging_id)->get();
        $selectedPackagingId = $defective->packaging_id ?? null;

        return view('admin.defective.edit', compact('packaging', 'id', 'defective', 'selectedPackagingId'));
    }
    public function view(Request $request, $id)
    {
        $defective = Defective::find($id);

        $packaging = PackagingSlip::where('id', $defective->packaging_id)->get();

        $selectedPackagingId = $defective->packaging_id ?? null;

        return view('admin.defective.view', compact('packaging', 'id', 'defective', 'selectedPackagingId'));
    }
    public function update(Request $request, $id)
    {
        $data = Defective::find($id);
        $data->packaging_id = $request->packaging_id;
        $data->item_id = $request->item_id;
        $data->quantity = $request->quantity;

        $data->update();
        return redirect()->route('admin.defective.list')->with('messages', [
            ['type' => 'success', 'message' => 'Defective updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = Defective::find($id);
        $data->delete();
        return redirect()->route('admin.defective.list')->with('messages', [
            ['type' => 'success', 'message' => 'Defective deleted successfully', 'title' => 'Success!']
        ]);
    }

    public function generatedefective($id)
    {
        $InwardItem = Defective::with('items', 'packagingSlip', 'color')->findOrFail(base64_decode($id));
        // dd($GatePass);

        //company details
        $data['id'] = $InwardItem->id;
        $data['jober_name'] = $InwardItem->packagingSlip->jober_name;

        // Get total quantity for this packaging_id (Check if packagingSlip exists)

        $data['defective'] = $InwardItem->quantity;

        // Get total inwarded quantity for this packaging_id

        // Calculate remaining quantity

        // Assign values to data array
        // $data['inwarded'] = $inwarded_quantity;


        $data['Bale_number'] = $InwardItem->packaging_id;
        $data['created_at'] = $InwardItem->created_at;

        // dd($data);

        // Generate and save the PDF        
        $pdf = Pdf::loadView('pdf.defective', compact('data'));
        $pdf->setPaper('A5', 'portrait');

        // return $pdf->stream('defective.pdf', ['Attachment' => false]);

        $savePath = public_path() . '/defective/' . $InwardItem->id . '.pdf';

        $pdf->save($savePath);

        // Return the PDF for download
        return $pdf->download($InwardItem->id . '_defective.pdf');
    }
    public function generatePdf($id)
    {
        $packagingSlip = PackagingSlip::with('items', 'assorting', 'color')->findOrFail(base64_decode($id));

        //company details
        $data['jober_name'] = $packagingSlip->jober_name;
        $data['quality'] = $packagingSlip->quality;
        $data['size'] = $packagingSlip->size;
        $data['waist'] = $packagingSlip->waist;
        $data['length'] = $packagingSlip->length;
        $data['girth'] = $packagingSlip->girth;
        $data['petticoat'] = $packagingSlip->petticoat;
        $data['interlock'] = $packagingSlip->interlock;
        $data['quantity'] = $packagingSlip->quantity;
        $data['receipt_number'] = $packagingSlip->receipt_number;
        $data['created_at'] = $packagingSlip->created_at;

        // Generate and save the PDF        
        $pdf = Pdf::loadView('pdf.invoice2', compact('packagingSlip', 'data'));
        // return $pdf->stream('packaging.pdf', ['Attachment' => false]);


        $pdf->setPaper('A5', 'portrait');
        // return $pdf->stream('result.pdf', ['Attachment' => false]);

        $savePath = public_path() . '/packaging-slip/' . $packagingSlip->receipt_number . '.pdf';

        $pdf->save($savePath);

        // Return the PDF for download
        return $pdf->download($packagingSlip->receipt_number . '_packaging.pdf');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\GlobalController;
use App\Models\ColorAssorting;
use App\Models\Assorting;
use App\Models\PackagingSlip;
use App\Models\Item;
use App\Models\Quality;
use Illuminate\Http\Request;
use PDF;

class PackagingSlipController extends GlobalController
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index()
    {
        $packaging = PackagingSlip::with('items', 'color', 'assorting')->where('is_delete', 0)
            ->orderBy('id', 'desc')
            ->get();

        return view('admin.packaging.list', compact('packaging'));
    }
    public function create()
    {
        $packaging = PackagingSlip::where('is_delete', 0)
            ->orderBy('id', 'desc')
            ->get();

        $qualities = Quality::get();
        $lastReceiptNumber = $packaging->isNotEmpty() ? preg_replace('/[^0-9]/', '', $packaging->first()->receipt_number) : 0;
        $newReceiptNumber = (int) $lastReceiptNumber + 1;
        return view('admin.packaging.add', compact('packaging', 'newReceiptNumber', 'qualities'));
    }
    public function store(Request $request)
    {
        // Validate incoming request
        $request->validate([
            'receipt_number' => 'required|string',
            'jober_name' => 'required|string',
            'quality' => 'required|string',
            'waist' => 'nullable|integer',
            'length' => 'nullable|integer',
            'girth' => 'nullable|integer',
            'petticoat' => 'nullable|string',
            'interlock' => 'nullable|string',
            'description' => 'required|array',
            'than' => 'required|array',
            'cut' => 'required|array',
            'meter' => 'required|array',
            'description.*' => 'required|string',
            'than.*' => 'required|numeric',
            'cut.*' => 'required|numeric',
            'meter.*' => 'required|numeric',
        ]);

        $totalmeter = array_sum($request->meter);
        $total_quantity = floor($totalmeter / $request->size);

        // Create Packaging Slip
        $packagingSlip = PackagingSlip::create([
            'receipt_number' => $request->receipt_number,
            'jober_name' => $request->jober_name,
            'quality' => $request->quality,
            'size' => $request->size,
            'waist' => $request->waist,
            'length' => $request->length,
            'girth' => $request->girth,
            'total_quantity' => $total_quantity,
            'petticoat' => $request->petticoat,
            'interlock' => $request->interlock,
            'assort' => $request->assort,
            'is_delete' => 0, // Default to active
        ]);

        // Store Items (if description array exists)
        if (!empty($request->description)) {
            foreach ($request->description as $index => $desc) {
                Item::create([
                    'packaging_slip_id' => $request->receipt_number,
                    'description' => $desc,
                    'than' => $request->than[$index] ?? 0,
                    'cut' => $request->cut[$index] ?? 0,
                    'meter' => $request->meter[$index] ?? 0,
                ]);
            }
        }
        if ($request->assort == 'yes') {
            // Loop through the color fields dynamically
            foreach ($request->all() as $key => $value) {
                // Check if the key matches the color field pattern (e.g., color_1, color_2, etc.)
                if (preg_match('/^color_\d+$/', $key)) {

                    // Only proceed if the color value is not empty or null
                    if (!empty($value)) {

                        // Get the corresponding quantity from the request, default to 0 if not provided
                        $quantity = $request->input('quantity')[$value] ?? 0;

                        // Save the entry only if color is not null
                        ColorAssorting::create([
                            'packaging_slip_id' => $request->receipt_number,
                            'color' => $key,
                            'quantity' => $value,
                        ]);
                    }
                }
            }
        }
        return redirect()->route('admin.packaging.list')->with('messages', [
            ['type' => 'success', 'message' => 'Packaging slip stored successfully', 'title' => 'Success!']
        ]);
    }
    public function view(Request $request, $id)
    {
        $data = PackagingSlip::find($id);
        $packaging = PackagingSlip::find($id);
        $description = Item::where('packaging_slip_id', $packaging->receipt_number)->get();
        $colorData = ColorAssorting::where('packaging_slip_id', $packaging->receipt_number)->get();

        return view('admin.packaging.view', compact('data', 'packaging', 'description', 'colorData'));
    }
    public function edit(Request $request, $id)
    {
        $packaging = PackagingSlip::find($id);
        $description = Item::where('packaging_slip_id', $packaging->receipt_number)->get();
        $qualities = Quality::get();
        $colorData = ColorAssorting::where('packaging_slip_id', $packaging->receipt_number)->get();

        return view('admin.packaging.edit', compact('packaging', 'qualities', 'description', 'colorData'));
    }
    public function update(Request $request, $id)
    {
        $data = PackagingSlip::find($id);
        $data->jober_name = $request->jober_name;
        $data->quality = $request->quality;
        $data->size = $request->size;
        $data->waist = $request->waist;
        $data->length = $request->length;
        $data->girth = $request->girth;

        $totalmeter = array_sum($request->meter);
        $total_quantity = floor($totalmeter / $request->size);

        $data->total_quantity = $total_quantity;
        $data->interlock = $request->interlock;
        $data->petticoat = $request->petticoat;
        $data->assort = $request->assort ?? 'no'; // default to 'no' if not present
        $data->update();

        // ----- Item Table Update -----
        if (!empty($request->description)) {
            $existingItemIds = $request->item_ids ?? [];
            $allDbItemIds = Item::where('packaging_slip_id', $id)->pluck('id')->toArray();

            $deletedItemIds = array_diff($allDbItemIds, $existingItemIds);
            Item::whereIn('id', $deletedItemIds)->delete();

            foreach ($request->description as $index => $desc) {
                $itemId = $existingItemIds[$index] ?? null;

                if ($itemId) {
                    $item = Item::find($itemId);
                } else {
                    $item = new Item();
                    $item->packaging_slip_id = $id;
                }

                $item->description = $desc;
                $item->than = $request->than[$index] ?? 0;
                $item->cut = $request->cut[$index] ?? 0;
                $item->meter = $request->meter[$index] ?? 0;
                $item->save();
            }
        }

        // ----- Assorting Update -----
        if ($request->assort === 'yes') {
            // Remove old color entries
            ColorAssorting::where('packaging_slip_id', $data->receipt_number)->delete();

            // Add new ones
            foreach ($request->all() as $key => $value) {
                if (preg_match('/^color_\d+$/', $key) && !empty($value)) {
                    ColorAssorting::create([
                        'packaging_slip_id' => $data->receipt_number,
                        'color' => $key,
                        'quantity' => $value,
                    ]);
                }
            }
        } else {
            // If changed to "No", delete previous color entries
            ColorAssorting::where('packaging_slip_id', $data->receipt_number)->delete();
        }

        return redirect()->route('admin.packaging.list')->with('messages', [
            ['type' => 'success', 'message' => 'Packaging slip updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = PackagingSlip::find($id);
        $data->delete();
        return redirect()->route('admin.packaging.list')->with('messages', [
            ['type' => 'success', 'message' => 'Packaging slip deleted successfully', 'title' => 'Success!']
        ]);
    }
    public function assorting($id)
    {
        // Find the packaging slip and load the related data
        $packagingSlip = PackagingSlip::with('items', 'assorting', 'color')->findOrFail(base64_decode($id));

        // Prepare data for the PDF view
        $data['Name'] = $packagingSlip->assorting->first()->name ?? "";
        $data['quality'] = $packagingSlip->quality ?? "";
        $data['transport'] = $packagingSlip->assorting->first()->transport ?? "";
        $data['post'] = $packagingSlip->assorting->first()->post ?? "";
        $data['screen'] = $packagingSlip->assorting->first()->screen ?? "";
        $data['than'] = $packagingSlip->items->first()->than ?? "";
        $data['bales'] = $packagingSlip->assorting->first()->bales ?? "";
        $data['rate'] = $packagingSlip->assorting->first()->rate ?? "";
        $data['quantity'] = $packagingSlip->quantity ?? "";
        $data['receipt_number'] = $packagingSlip->receipt_number ?? "";
        $data['created_at'] = $packagingSlip->created_at ?? "";

        // Generate the PDF using the 'assorting' view and pass the data
        $pdf = Pdf::loadView('pdf.assorting', compact('packagingSlip', 'data'));

        // Set the paper size and orientation for the PDF
        $pdf->setPaper('A4', 'portrait');

        // Define the path where the PDF will be saved
        $savePath = public_path() . '/assorting/' . $packagingSlip->receipt_number . '.pdf';

        // Save the PDF to the specified path
        $pdf->save($savePath);

        // Return the PDF for download
        return $pdf->download($packagingSlip->receipt_number . '_assorting.pdf');
    }
}
<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Sample;
use App\Models\Quality;

class SampleController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index()
    {
        $inward = Sample::get();
        return view('admin.sample.list', compact('inward'));
    }
    public function create(Request $request)
    {
        $nextId = Sample::max('id') + 1;
        $qualities = Quality::get();

        $Sample = Sample::orderBy('id', 'desc')
            ->get();

        return view('admin.sample.add', compact('Sample', 'nextId', "qualities"));
    }
    public function view(Request $request, $id)
    {
        $qualities = Quality::get();
        $Sample = Sample::find($id);

        return view('admin.sample.view', compact('Sample', 'id', "qualities"));
    }
    public function store(Request $request)
    {
        Sample::create([
            'quality' => $request->quality,
            'name' => $request->name,
            'quantity' => $request->quantity,
        ]);

        return redirect()->route('admin.sample.list')->with('messages', [
            ['type' => 'success', 'message' => 'Sample stored successfully', 'title' => 'Success!']
        ]);
    }
    public function edit(Request $request, $id)
    {
        $qualities = Quality::get();
        $Sample = Sample::find($id);

        return view('admin.sample.edit', compact('Sample', 'id', "qualities"));
    }
    public function update(Request $request, $id)
    {
        $data = Sample::find($id);
        $data->quality = $request->quality;
        $data->name = $request->name;
        $data->quantity = $request->quantity;

        $data->update();
        return redirect()->route('admin.sample.list')->with('messages', [
            ['type' => 'success', 'message' => 'Sample updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = Sample::find($id);
        $data->delete();
        return redirect()->route('admin.sample.list')->with('messages', [
            ['type' => 'success', 'message' => 'Sample deleted successfully', 'title' => 'Success!']
        ]);
    }
    public function generatesample($id)
    {
        $id = base64_decode($id); // Decode the ID
        $InwardItem = Sample::find($id); // Fetch the record using Eloquent

        //company details
        $data['id'] = $InwardItem->id;
        $data['name'] = $InwardItem->name;
        $data['quality'] = $InwardItem->quality;
        $data['quantity'] = $InwardItem->quantity;
        $data['created_at'] = $InwardItem->created_at;

        // Generate and save the PDF        
        $pdf = Pdf::loadView('pdf.sample', compact('data'));
        $pdf->setPaper('A5', 'portrait');

        // return $pdf->stream('inward.pdf', ['Attachment' => false]);

        $savePath = public_path() . '/sample/' . $InwardItem->id . '.pdf';

        $pdf->save($savePath);

        // Return the PDF for download
        return $pdf->download($InwardItem->id . '_sample.pdf');
    }
}
<?php

namespace App\Http\Controllers\Admin;
use App\Models\Quality;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class QualityController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index(request $request)
    {
        // dd($request->all());
        $Quality = Quality::get();
        //   dd($defective);
        return view('admin.quality.list', compact('Quality'));
    }
    public function create(Request $request)
    {
        return view('admin.quality.add');
    }

    public function store(Request $request)
    {
        // dd($request->all());

        // Create Gate Pass
        Quality::create([
            'name' => $request->name,
            'size' => $request->size,
        ]);

        return redirect()->route('admin.quality.list')->with('messages', [
            ['type' => 'success', 'message' => 'Quality Added successfully', 'title' => 'Success!']
        ]);
    }
    public function edit(Request $request, $id)
    {

        $quality = Quality::find($id);
        return view('admin.quality.edit', compact('quality'));
    }

    public function update(Request $request, $id)
    {
        $data = Quality::find($id);
        $data->name = $request->name;
        $data->size = $request->size;
        $data->update();
        return redirect()->route('admin.quality.list')->with('messages', [
            ['type' => 'success', 'message' => 'Quality updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = Quality::find($id);
        $data->delete();
        return redirect()->route('admin.quality.list')->with('messages', [
            ['type' => 'success', 'message' => 'Quality deleted successfully', 'title' => 'Success!']
        ]);
    }
}

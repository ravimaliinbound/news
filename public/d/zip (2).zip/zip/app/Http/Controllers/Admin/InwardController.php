<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InwardItem;
use App\Models\PackagingSlip;
use App\Models\GatePass;
use App\Models\Warehouse;
use Carbon\Carbon;
use PDF;
class InwardController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index()
    {
        $inward = InwardItem::with('packagingSlip', 'items', 'color', 'gatePass', 'warehouse')->get();
        return view('admin.inward.list', compact('inward'));
    }
    public function create(Request $request)
    {
        $nextId = InwardItem::max('id') + 1;
        $packaging = PackagingSlip::with(['items', 'color', 'assorting', 'inwarded'])
            ->where('is_delete', 0)
            ->orderBy('id', 'desc')
            ->get();
        $gatepass = GatePass::with('packagingSlip')->get();

        $warehouse = Warehouse::get();
        return view('admin.inward.add', compact('packaging', 'nextId', 'gatepass', 'warehouse'));
    }

    public function store(Request $request)
    {


        // dd($request);
        // Get the packaging slip details using packaging_id
        $packaging = PackagingSlip::find($request->packaging_id); // assuming PackagingSlip model

        if (!$packaging) {
            return back()->with('messages', [
                ['type' => 'error', 'message' => 'Packaging not found.', 'title' => 'Error!']
            ]);
        }

        // Sum of already inwarded quantity for this packaging ID from InwardItem
        $inwardedQuantity = InwardItem::where('packaging_id', $request->packaging_id)->sum('inward_quantity');

        // Calculate remaining quantity
        $remainingQuantity = $packaging->total_quantity - $inwardedQuantity;
        // Subtract the current inward quantity from the remaining quantity
        $remainingQuantity -= $request->inward_quantity;
        // dd($remainingQuantity);

        // dd($request->inward_quantity);
        // dd($remainingQuantity, $request->all());

        // Optional: check if requested inward exceeds remaining quantity
        if ($request->inward_quantity > $remainingQuantity) {
            return back()->with('messages', [
                ['type' => 'error', 'message' => 'Inward quantity exceeds remaining quantity.', 'title' => 'Error!']
            ]);
        }

        // Create new inward item record
        $inward = new InwardItem();
        $inward->packaging_id = $request->packaging_id;
        $inward->item_id = $request->item_id;
        $inward->gate_pass_id = $request->gate_pass_number;
        $inward->ware_house_id = $request->ware_house_id;
        $inward->inward_quantity = $request->inward_quantity;
        $inward->remaining_quantity = $remainingQuantity; // Update remaining quantity for this inward
        $inward->date = Carbon::createFromFormat('d/m/Y h:i A', $request->date)->format('Y-m-d H:i:s');
        $inward->save();

        return redirect()->route('admin.inward.list')->with('messages', [
            ['type' => 'success', 'message' => 'Inward stored successfully.', 'title' => 'Success!']
        ]);

        // $inward = new InwardItem();
        // $inward->packaging_id = $request->packaging_id;
        // $inward->item_id = $request->item_id;
        // $inward->gate_pass_id = $request->gate_pass_id;
        // $inward->ware_house_id = $request->ware_house_id;
        // $inward->inward_quantity = $request->inward_quantity;
        // $inward->date = Carbon::createFromFormat('d/m/Y h:i A', $request->date)->format('Y-m-d H:i:s');
        // $inward->save();

        // return redirect()->route('admin.inward.list')->with('messages', [
        //     ['type' => 'success', 'message' => 'Inward stored successfully', 'title' => 'Success!']
        // ]);
    }
    public function view(Request $request, $id)
    {
        $inward = InwardItem::find((base64_decode($id)));
        $packaging = PackagingSlip::where('id', $inward->packaging_id)->get();
        $gatepass = GatePass::with('packagingSlip')->get();
        $warehouse = Warehouse::get();
        $already_inwarded = DB::table('inward_items')
            ->join('packaging_receipts', 'inward_items.packaging_id', '=', 'packaging_receipts.id')
            ->where('packaging_receipts.id', '=', $inward->packaging_id)
            ->where('inward_items.id', '<', $inward->id)
            ->sum('inward_items.inward_quantity');

        return view('admin.inward.view', compact('packaging', 'id', 'gatepass', 'warehouse', 'inward', 'already_inwarded'));
    }
    public function edit(Request $request, $id)
    {
        $inward = InwardItem::find($id);
        $packaging = PackagingSlip::where('id', $inward->packaging_id)->get();
        $gatepass = GatePass::with('packagingSlip')->get();
        $warehouse = Warehouse::get();

        return view('admin.inward.edit', compact('packaging', 'id', 'gatepass', 'warehouse', 'inward'));
    }
    public function update(Request $request, $id)
    {
        $data = InwardItem::find($id);
        $data->packaging_id = $request->packaging_id;
        $data->item_id = $request->item_id;
        $data->gate_pass_id = $request->gate_pass_id;
        $data->ware_house_id = $request->ware_house_id;
        $data->inward_quantity = $request->inward_quantity;

        $data->update();
        return redirect()->route('admin.inward.list')->with('messages', [
            ['type' => 'success', 'message' => 'Inward updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = InwardItem::find($id);
        $data->delete();
        return redirect()->route('admin.inward.list')->with('messages', [
            ['type' => 'success', 'message' => 'Inward deleted successfully', 'title' => 'Success!']
        ]);
    }
    public function generateinward($id)
    {
        $InwardItem = InwardItem::with('items', 'packagingSlip', 'color', 'warehouse', 'gatePass')->findOrFail(base64_decode($id));

        //company details
        $data['id'] = $InwardItem->id;
        $data['jober_name'] = $InwardItem->packagingSlip->jober_name;

        $total_quantity = $InwardItem->packagingSlip->total_quantity ?? 0;

        $data['inwarded'] = $InwardItem->inward_quantity;
        $data['warehouse'] = $InwardItem->warehouse->name ?? "";
        $data['date'] = $InwardItem->date ?? "";

        $inwarded_quantity = InwardItem::where('packaging_id', $InwardItem->packaging_id)->sum('inward_quantity');

        // Calculate remaining quantity
        $remaining_quantity = max(0, $total_quantity - $inwarded_quantity);

        // Assign values to data array
        $data['quantity'] = $total_quantity;
        // $data['inwarded'] = $inwarded_quantity;
        $data['remaining'] = $remaining_quantity;


        $data['Bale_number'] = $InwardItem->packaging_id;
        $data['created_at'] = $InwardItem->created_at;


        // Generate and save the PDF        
        $pdf = Pdf::loadView('pdf.inward', compact('data'));
        $pdf->setPaper('A5', 'portrait');

        // return $pdf->stream('inward.pdf', ['Attachment' => false]);

        $savePath = public_path() . '/inward/' . $InwardItem->id . '.pdf';

        $pdf->save($savePath);

        // Return the PDF for download
        return $pdf->download($InwardItem->id . '_inward.pdf');
    }
}
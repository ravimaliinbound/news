<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Warehouse;

class WareHouseController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index(request $request)
    {
        $warehouse = Warehouse::get();

        return view('admin.warehouse.list', compact('warehouse'));
    }
    public function create(Request $request)
    {
        return view('admin.warehouse.add');
    }
    public function store(Request $request)
    {
        Warehouse::create([
            'name' => $request->name,
        ]);

        return redirect()->route('admin.warehouse.list')->with('messages', [
            ['type' => 'success', 'message' => 'Warehouse Added successfully', 'title' => 'Success!']
        ]);
    }
    public function edit(Request $request, $id)
    {
        $warehouse = Warehouse::find($id);
        return view('admin.warehouse.edit', compact('warehouse'));
    }
    public function update(Request $request, $id)
    {
        $data = Warehouse::find($id);
        $data->name = $request->name;
        $data->update();
        return redirect()->route('admin.warehouse.list')->with('messages', [
            ['type' => 'success', 'message' => 'Warehouse updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = Warehouse::find($id);
        $data->delete();
        return redirect()->route('admin.warehouse.list')->with('messages', [
            ['type' => 'success', 'message' => 'Warehouse deleted successfully', 'title' => 'Success!']
        ]);
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GatePass;
use App\Models\PackagingSlip;
use PDF;

class GatePassController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }
    public function index()
    {
        $packaging = GatePass::with('packagingSlip')->get();

        return view('admin.gatepass.list', compact('packaging'));
    }
    public function create(Request $request)
    {
        $nextId = GatePass::max('id') + 1;
        $packaging = PackagingSlip::with(['items', 'color', 'assorting'])
            ->where('is_delete', 0)
            ->orderBy('id', 'desc')
            ->get();

        return view('admin.gatepass.create', compact('packaging', 'nextId'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'packaging_id' => 'required|string',
            'than' => 'required',
            'meter' => 'required',
            'delivery_location' => 'required|string',
            'car_number' => 'required|string',
            'driver_name' => 'required|string',
        ]);

        // Create Gate Pass
        GatePass::create([
            'packaging_id' => $request->packaging_id,
            'than' => $request->than,
            'meter' => $request->meter,
            'delivery_location' => $request->delivery_location,
            'car_number' => $request->car_number,
            'driver_name' => $request->driver_name,
        ]);

        return redirect()->route('admin.gatepass.list')->with('messages', [
            ['type' => 'success', 'message' => 'Gate pass stored successfully', 'title' => 'Success!']
        ]);
    }
    public function view(Request $request, $id)
    {
        $gatepass = GatePass::find($id);
        $packaging = PackagingSlip::where('id', $gatepass->packaging_id)->get();

        return view('admin.gatepass.view', compact('packaging', 'gatepass'));
    }
    public function edit(Request $request, $id)
    {
        $gatepass = GatePass::find($id);
        $packaging = PackagingSlip::where('id', $gatepass->packaging_id)->get();
        return view('admin.gatepass.edit', compact('gatepass', 'id', 'packaging'));
    }
    public function update(Request $request, $id)
    {
        $data = GatePass::find($id);
        $data->packaging_id = $request->packaging_id;
        $data->than = $request->than;
        $data->meter = $request->meter;
        $data->delivery_location = $request->delivery_location;
        $data->car_number = $request->car_number;
        $data->driver_name = $request->driver_name;

        $data->update();
        return redirect()->route('admin.gatepass.list')->with('messages', [
            ['type' => 'success', 'message' => 'Gate pass updated successfully', 'title' => 'Success!']
        ]);
    }
    public function destroy(Request $request, $id)
    {
        $data = GatePass::find($id);
        $data->delete();
        return redirect()->route('admin.gatepass.list')->with('messages', [
            ['type' => 'success', 'message' => 'Gate pass deleted successfully', 'title' => 'Success!']
        ]);
    }
    public function generateGatePass($id)
    {
        $GatePass = GatePass::with('items', 'packagingSlip')->findOrFail(base64_decode($id));

        //company details
        $data['id'] = $GatePass->id;
        $data['jober_name'] = $GatePass->packagingSlip->jober_name;
        $data['Bale_number'] = $GatePass->packaging_id;
        $data['than'] = $GatePass->than;
        $data['meter'] = $GatePass->meter;
        $data['delivery_location'] = $GatePass->delivery_location;
        $data['car_number'] = $GatePass->car_number;
        $data['driver_name'] = $GatePass->driver_name;
        $data['bundle'] = $GatePass->bundle;
        $data['created_at'] = $GatePass->created_at;

        // Generate and save the PDF        
        $pdf = Pdf::loadView('pdf.gatePass', compact('data'));
        $pdf->setPaper('A5', 'portrait');

        // return $pdf->stream('gatePass.pdf', ['Attachment' => false]);

        $savePath = public_path() . '/gate-pass/' . $GatePass->id . '.pdf';

        $pdf->save($savePath);

        // Return the PDF for download
        return $pdf->download($GatePass->id . '_gate-pass.pdf');
    }
}
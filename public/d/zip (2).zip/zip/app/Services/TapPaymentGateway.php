<?php

namespace App\Services;

class TapPaymentGateway
{
}

<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h1 class="mb-sm-0 font-size-32">Dashboard -Coming Soon</h1>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard <?php echo e(Auth::guard('admin')->user()->role_id); ?></a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exhibitor-plexpo\palrecha\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>
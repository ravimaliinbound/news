
<?php $__env->startSection('title', 'Inquiry List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">packaging List</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Packaging List</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>

            <!-- end page title -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <a href="<?php echo e(route('admin.packaging.create')); ?>" class="btn btn-primary float-right"> Add
                                Packaging Slip
                            </a><br /><br />
                            <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <tr>
                                        <th style="width: 5%;">ID</th>
                                        <th style="width: 5%;">Receipt Number</th>
                                        <th style="width: 25%;">Jober Name</th>
                                        <th style="width: 25%;">Quality</th>
                                        <th style="width: 15%;">Size</th>
                                        <th style="width: 45%;">Total Quantity</th>
                                        <th style="width: 45%;"> Packaging Slip</th>
                                        <th style="width: 45%;"> Assorting Slip</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!is_null($packaging)): ?>
                                        <?php $__currentLoopData = $packaging; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ok => $ov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($ov->id); ?></td>
                                                <td>#<?php echo e($ov->receipt_number); ?></td>
                                                <td><?php echo e($ov->jober_name); ?></td>
                                                <td><?php echo e($ov->quality); ?></td>
                                                <td><?php echo e($ov->size); ?></td>
                                                <td>
                                                    <?php echo e($ov->total_quantity); ?>

                                                </td>                                              
                                                <td>
                                                    <a href="<?php echo e(route('admin.packaging.generatePdf', base64_encode($ov->id) )); ?>"><i style="font-size: 1.55rem;" class="mdi mdi-download"></i></a>                     
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.packaging.assorting', base64_encode($ov->id) )); ?>"><i style="font-size: 1.55rem;" class="mdi mdi-download"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </div> <!-- container-fluid -->
    </div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exhibitor-plexpo\palrecha\resources\views/admin/packaging/list.blade.php ENDPATH**/ ?>
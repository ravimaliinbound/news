<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?> | </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" href="<?php echo e(asset('/')); ?>" type="image/gif" sizes="48x48">
        <?php echo $__env->make('components.admin.partials.header_link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body data-sidebar="dark">
        <div id="layout-wrapper">
            <?php if (isset($component)) { $__componentOriginal6f6f698520bdcfb3f00f726683166380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f6f698520bdcfb3f00f726683166380 = $attributes; } ?>
<?php $component = App\View\Components\AdminTopnavigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-topnavigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminTopnavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f6f698520bdcfb3f00f726683166380)): ?>
<?php $attributes = $__attributesOriginal6f6f698520bdcfb3f00f726683166380; ?>
<?php unset($__attributesOriginal6f6f698520bdcfb3f00f726683166380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f6f698520bdcfb3f00f726683166380)): ?>
<?php $component = $__componentOriginal6f6f698520bdcfb3f00f726683166380; ?>
<?php unset($__componentOriginal6f6f698520bdcfb3f00f726683166380); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $attributes; } ?>
<?php $component = App\View\Components\AdminSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $attributes = $__attributesOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__attributesOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $component = $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
                <?php if (isset($component)) { $__componentOriginal4c5bbc9a2d53d24d7188884ff0365c23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c5bbc9a2d53d24d7188884ff0365c23 = $attributes; } ?>
<?php $component = App\View\Components\AdminFooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c5bbc9a2d53d24d7188884ff0365c23)): ?>
<?php $attributes = $__attributesOriginal4c5bbc9a2d53d24d7188884ff0365c23; ?>
<?php unset($__attributesOriginal4c5bbc9a2d53d24d7188884ff0365c23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c5bbc9a2d53d24d7188884ff0365c23)): ?>
<?php $component = $__componentOriginal4c5bbc9a2d53d24d7188884ff0365c23; ?>
<?php unset($__componentOriginal4c5bbc9a2d53d24d7188884ff0365c23); ?>
<?php endif; ?>
                <?php echo $__env->make('components.admin.partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
        <div class="rightbar-overlay"></div>
        <?php echo $__env->make('components.admin.partials.footer_link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('js'); ?>
        <script type="text/javascript">
            <?php if(Session::has('messages')): ?>
                $(document).ready(function() {
                    <?php $__currentLoopData = Session::get('messages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        toastr['<?php echo e($msg["type"]); ?>']('<?php echo e($msg["message"]); ?>','<?php echo e($msg["title"]); ?>');
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                });
            <?php endif; ?>
            
            <?php if(count($errors) > 0): ?> 
                $(document).ready(function() {
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        toastr['error']('<?php echo e($error); ?>');
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                });
            <?php endif; ?>


           
        </script>
    </body>
</html><?php /**PATH C:\Users\DELL\Downloads\zip\resources\views/layouts/admin.blade.php ENDPATH**/ ?>